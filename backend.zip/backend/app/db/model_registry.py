# Import models so SQLAlchemy registers them

from app.ingestion.enrichment.models.indicator_models import Indicator
from app.ingestion.enrichment.models.campaign_models import Campaign
from app.ingestion.enrichment.models.timeline_models import CampaignTimeline
from app.ingestion.enrichment.models.indicator_metadata_model import IndicatorMetadata
from app.ingestion.enrichment.models.infrastructure_models import IndicatorEnrichment